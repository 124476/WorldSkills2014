﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using WorldSkills2014.Models;

namespace WorldSkills2014
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static WorldSkillsEntities1 DB = new WorldSkillsEntities1();
        public static Employee user;
        public static Employee userSave;
    }
}
