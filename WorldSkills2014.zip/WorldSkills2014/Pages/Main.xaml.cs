﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WorldSkills2014.Models;

namespace WorldSkills2014.Pages
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Page
    {
        Employee user;
        public Main(Employee conUser)
        {
            InitializeComponent();
            user = conUser;
            TextHello.Text = "Hello " + user.Name + "!";
            List<ChatMessage> allMess = new List<ChatMessage>();
            foreach (Chatroom ch in App.DB.Chatroom)
            {
                if (App.DB.ChatroomMember.FirstOrDefault(x => x.Chatroom_Id == ch.Id && x.Employee_Id == user.Id) != null)
                {
                    ChatMessage mess = App.DB.ChatMessage.OrderBy(x => x.Date).FirstOrDefault(x => x.Chatroom_Id == ch.Id);
                    if (mess == null)
                    {
                        ChatMessage mes = new ChatMessage();
                        mes.Chatroom_Id = ch.Id;
                        mes.Chatroom = ch;
                        allMess.Add(mes);
                    }
                    else
                    {
                        allMess.Add(mess);
                    }
                }
            }

            DGChats.ItemsSource = allMess.OrderByDescending(x => x.Date);
        }

        private void Employee_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Poisk(user, null));
        }

        private void CloseApp_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Opened());
        }

        private void Prof_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Register(App.user));
        }

        private void DGChats_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (DGChats.SelectedItem is ChatMessage depart)
            {
                ChatroomMember depar = App.DB.ChatroomMember.FirstOrDefault(x => x.Chatroom_Id == depart.Chatroom_Id
                && x.Employee_Id == user.Id);
                NavigationService.Navigate(new Chat(depar));
            }
        }
    }
}
